# ProtoVid Figma Community Listing

## Name

ProtoVid - Export Figma Prototypes to MP4

## Tagline

Turn connected Figma prototype flows into client-ready MP4 walkthroughs.

## Description

Skip screen recording. ProtoVid turns connected Figma prototype flows into shareable MP4 walkthroughs for client reviews, pitch decks, design handoff, docs, and portfolio case studies.

What it does:
• Detects connected prototype frames on the current page
• Exports the flow as an MP4 walkthrough
• Starts with 3 free watermarked 720p exports per month
• Unlocks watermark-free HD/4K exports with Pro
• Works well for client presentations, stakeholder updates, and handoff documentation

Best for:
• Client and stakeholder reviews
• Pitch decks and product demos
• Design handoff and developer docs
• Portfolio walkthroughs and case studies

Set up a connected Figma prototype, run ProtoVid, export the MP4, and send the walkthrough without recording your screen.

## Category

Prototyping & animation

## Tags

Recommended tags:
• Interactive
• Motion

Custom tags:
• mp4
• prototype demo
• screen recording
• video export
• client presentation
• design handoff

## Images

Thumbnail:
• protovid-thumbnail.png

Carousel order:
1. protovid-carousel-1-detect.png
2. protovid-carousel-2-success.png
3. protovid-carousel-3-free.png
4. protovid-carousel-4-pro.png

## Version Notes

Improved export reliability for larger prototype flows, clearer Free and Pro options, post-export email save for faster checkout, Large Flow Pass for complex flows, and a stronger review prompt after successful exports.
